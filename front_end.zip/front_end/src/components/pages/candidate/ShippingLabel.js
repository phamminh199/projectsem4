import { jsPDF } from "jspdf";
import Barcode from "./barcode.png";

const ShippingLabel = () => {    
    const createPDF = async () => {
        // TODO
    }; 
    return (<>{/* TODO */}</>);
};

export default ShippingLabel;