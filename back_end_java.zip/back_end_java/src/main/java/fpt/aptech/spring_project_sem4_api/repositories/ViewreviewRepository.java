
package fpt.aptech.spring_project_sem4_api.repositories;

import fpt.aptech.spring_project_sem4_api.entities.Viewreview;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ViewreviewRepository extends JpaRepository<Viewreview, Integer> {
    
}
