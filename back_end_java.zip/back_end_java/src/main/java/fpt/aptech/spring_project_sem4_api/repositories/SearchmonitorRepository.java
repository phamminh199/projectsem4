
package fpt.aptech.spring_project_sem4_api.repositories;

import fpt.aptech.spring_project_sem4_api.entities.Searchmonitor;
import org.springframework.data.jpa.repository.JpaRepository;


public interface SearchmonitorRepository extends JpaRepository<Searchmonitor, Integer> {
    
}
