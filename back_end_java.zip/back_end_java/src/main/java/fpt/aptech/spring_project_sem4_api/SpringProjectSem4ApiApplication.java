package fpt.aptech.spring_project_sem4_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringProjectSem4ApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringProjectSem4ApiApplication.class, args);
	}

}
