package fpt.aptech.spring_project_sem4_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringProjectSem4ApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
